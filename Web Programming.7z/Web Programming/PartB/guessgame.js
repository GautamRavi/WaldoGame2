var guessLimit = 3;
var randomNumber = Math.floor((Math.random() *100)+1);
var keepGoing = true;
var num;
while(keepGoing){
	keepGoing = false;
	num = parseInt(prompt("Guess:"));
	if(guessLimit == 1){
		alert("You lose");
	}else{
		if(num > randomNumber){
			alert("Too high");
			keepGoing = true;
			guessLimit--;
		}else if(num < randomNumber){
			alert("Too low");
			keepGoing = true
			guessLimit--;
		}else{
			alert("Correct");
			if(confirm("Would you like to play again?")){
				guessLimit = 3;
				randomNumber = Math.floor((Math.random() *100)+1);
				keepGoing = true;
			}else{
				alert("Thanks for playing");
			}
		}
	}
}