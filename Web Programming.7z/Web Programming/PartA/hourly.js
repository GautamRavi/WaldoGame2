var keepGoing = true;
var counter = 1;
var table = document.getElementById("table")
var row;
var employee;
var pay;
var total = 0;
while(keepGoing){
	keepGoing = false;
	var hoursWorked = parseInt(prompt("Hours worked? (Hit -1 to escape)","40"));
	if(hoursWorked != -1){
		keepGoing = true;
		employee = counter;
		pay = calculatePay(hoursWorked);
		writeToTable(employee, hoursWorked, pay);
		counter++;
		total += pay;
	}
}

function writeToTable(employee,hours,pay){
	var table = document.getElementById("table");
	var row = table.insertRow(counter);
	var employeeCell = row.insertCell(0);
	var hourCell = row.insertCell(1);
	var payCell = row.insertCell(2);
	
	employeeCell.innerHTML = employee;
	hourCell.innerHTML = hours;
	payCell.innerHTML = pay;
}

function calculatePay(hours){
	if(hours >= 40){
		var overTime = hours - 40;
		return (40*15) + (overTime*15*1.5);
	}
	return hours * 15;
}

document.write("Total Pay:" + total);